__author__ = "Daksh Patel"

aws_access_key_id = 'AKIA5WTK4BJPARQ7JDBC'
aws_secret_access_key  = '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'
region = 'us-east-2'